var express = require("express");
var app = express();
var session = require("cookie-session");
var cookieParser = require('cookie-parser')
var bodyParser = require('body-parser')

app.use(cookieParser())
.use(session({secret: 'todotopsecret'}))
.use(bodyParser())

var index = function(request, result){
	result.setHeader("Content-Type", "text/plain");
	result.end("Tu es sur l'index pauvre fou!");
};

var notExist = function(request, result) {
	result.setHeader("Content-Type", "text/plain");
	result.end("Il n'y a pas de page!");
};

//Avec des paramètres
var withParams = function(request, result) {
	result.setHeader("Content-Type", "text/html");
	result.render("personne.ejs",{nom : request.params.nom, prenom : request.params.prenom});
};


var showList = function(request, result){
	var myList = request.session.list;
	if(null == myList) {
		myList = new Array();
	}
	request.session.list=myList;
	result.setHeader("Content-Type", "text/html");
	result.render("showList.ejs",{list : myList});
};

var addElementToList = function(request, result){
	var value = request.body.value;
	if(null != value) {
		console.log(value);
		var list = request.session.list;
		if(null == list) {
			list = new Array();
		}
		list.push(value);
		request.session.list=list;
		console.log(request.session.list);
		showList(request, result);
	} else {
		index(request, result);
	}
};
var deleteElementToList = function(request, result) {
	var list = request.session.list;
	if(null != list){
		list.splice(request.params.id, 1);
		request.session.list=list;
		showList(request, result);
	} else {
		index(request, result);
	}
}
app.get("/", index)
.get("/:nom/:prenom", withParams)
.post("/list", addElementToList)
.get("/list", showList)
.get("/list/delete/:id", deleteElementToList)
app.use(notExist);
app.listen(80);

